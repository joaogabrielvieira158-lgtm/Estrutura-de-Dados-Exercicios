public class Main {
    public static void main(String[] args) {
        int[] vetor = new int[50];

        System.out.println("Vetor Embaralhado:");
        for(int i = 0; i < vetor.length; i++){
            vetor[i] = (int) (Math.random() * vetor.length);
            System.out.print(vetor[i] + "  ");
        }
        int h = 1;
        int t = vetor.length;
        while(h < t){
            h = h * 3 + 1;
        }
        h = (int) Math.floor(h / 3);
    }
}
